from resources.lib.kodion import runner
from resources.lib import nine_gag

__provider__ = nine_gag.Provider()
runner.run(__provider__)