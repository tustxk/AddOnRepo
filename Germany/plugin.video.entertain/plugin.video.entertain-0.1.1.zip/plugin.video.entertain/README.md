XBMC T-Entertain Plugin
=======================

About
-----

The XBMC Entertain Plugin integrates live TV streaming via [Deutsche Telekom's
Entertain] [1] IPTV service into XBMC. It allows to view all german public
channels (Öffentlich-Rechtliche Sender) in XBMC.


License
-------
This software is released under the [GPL 2.0 license] [2].


[1]: http://www.entertain.de
[2]: http://www.gnu.org/licenses/gpl-2.0.html
