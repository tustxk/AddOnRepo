# Copyright (c) The PyAMF Project.
# See LICENSE.txt for details.