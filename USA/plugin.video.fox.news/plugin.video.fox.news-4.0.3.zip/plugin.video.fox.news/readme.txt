Version 4.0.1
Updated for Gotham. Fixed website changes

Version 3.1.6
Added sub-categories directory listing

Version 3.1.5
Fix website changes

Version 3.1.1
fix website changes

Version 3.1.0
added videos from video.foxbusiness.com
we are now using multi-bitrate m3u8 streams, quality depends on the system bandwidth limit setting

Version 3.0.0
major version bump for frodo
fix website changes

Version 2.0.7
fix website changes

Version 2.0.6
fix website changes

Version 2.0.5
fix for setting type change

Version 2.0.4
updated to reflect website changes

Version 2.0.3
fix for changes to the common cache plugin
added a play mode for video directories