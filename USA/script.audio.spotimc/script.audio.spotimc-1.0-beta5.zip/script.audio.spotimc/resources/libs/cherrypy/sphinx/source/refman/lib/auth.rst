************************
:mod:`cherrypy.lib.auth`
************************

.. automodule:: cherrypy.lib.auth

Functions
=========

.. autofunction:: check_auth

.. autofunction:: basic_auth

.. autofunction:: digest_auth
