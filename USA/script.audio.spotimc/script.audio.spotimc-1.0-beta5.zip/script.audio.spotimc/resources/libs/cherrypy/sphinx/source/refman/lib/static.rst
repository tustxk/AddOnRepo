**************************
:mod:`cherrypy.lib.static`
**************************

.. automodule:: cherrypy.lib.static

Functions
=========

.. autofunction:: serve_file

.. autofunction:: serve_fileobj

.. autofunction:: serve_download

.. autofunction:: staticdir

.. autofunction:: staticfile

