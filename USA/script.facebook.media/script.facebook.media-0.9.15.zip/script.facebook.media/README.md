script.facebook.media
=====================

Facebook Media addon for Kodi (XBMC) - view your and your friends Facebook photos and videos
----------------------------
Allows viewing your Facebook media in Kodi, along with comments and face-matched tags.

Installation should be done through Kodi System::Settings::Add-ons::Get Add-Ons::All Add-Ons::Program Add-Ons::Facebook-media

If you want to ensure you are using the latest version of the addon you can install my [repository .zip file](http://ruuks-repo.googlecode.com/files/ruuk.addon.repository-1.0.0.zip).

Installation of the repository should be done through Kodi System::Settings::Add-ons::Install from zip file

Support is available at: http://forum.xbmc.org/showthread.php?tid=82500
