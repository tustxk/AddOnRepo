addon_id="script.icechannel.Firedrive.settings"
addon_name="iStream - Firedrive - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
