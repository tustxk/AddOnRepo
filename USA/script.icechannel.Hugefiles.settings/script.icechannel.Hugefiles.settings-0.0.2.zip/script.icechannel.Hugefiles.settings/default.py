addon_id="script.icechannel.Hugefiles.settings"
addon_name="iStream - Hugefiles - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
