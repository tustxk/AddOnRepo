addon_id="script.icechannel.Movpod.settings"
addon_name="iStream - Movpod - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
