addon_id="script.icechannel.Movshare.net.settings"
addon_name="iStream - Movshare.net - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
