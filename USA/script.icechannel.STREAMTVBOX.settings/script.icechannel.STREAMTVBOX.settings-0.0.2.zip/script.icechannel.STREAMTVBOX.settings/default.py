addon_id="script.icechannel.STREAMTVBOX.settings"
addon_name="iStream - STREAMTVBOX - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
