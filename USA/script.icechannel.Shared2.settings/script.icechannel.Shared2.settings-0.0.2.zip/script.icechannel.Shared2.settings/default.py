addon_id="script.icechannel.Shared2.settings"
addon_name="iStream - Shared2 - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
