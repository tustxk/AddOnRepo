addon_id="script.icechannel.Thevideome.settings"
addon_name="iStream - Thevideome - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
