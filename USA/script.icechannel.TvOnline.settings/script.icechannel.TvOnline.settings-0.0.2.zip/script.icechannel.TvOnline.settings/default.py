addon_id="script.icechannel.TvOnline.settings"
addon_name="iStream - TvOnline - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
