addon_id="script.icechannel.Usefile.settings"
addon_name="iStream - Usefile - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
