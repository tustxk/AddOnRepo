addon_id="script.icechannel.Vidto.settings"
addon_name="iStream - Vidto - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
