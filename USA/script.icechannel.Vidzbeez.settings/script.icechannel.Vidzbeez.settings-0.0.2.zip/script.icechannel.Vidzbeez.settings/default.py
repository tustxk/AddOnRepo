addon_id="script.icechannel.Vidzbeez.settings"
addon_name="iStream - Vidzbeez - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
