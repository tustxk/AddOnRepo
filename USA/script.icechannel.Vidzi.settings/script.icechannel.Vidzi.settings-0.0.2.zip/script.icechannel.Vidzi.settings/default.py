addon_id="script.icechannel.Vidzi.settings"
addon_name="iStream - Vidzi - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
