addon_id="script.icechannel.Xvidstage.settings"
addon_name="iStream - Xvidstage - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
