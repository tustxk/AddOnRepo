addon_id="script.icechannel.Youporn.settings"
addon_name="iStream - Youporn - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
