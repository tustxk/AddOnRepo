addon_id="script.icechannel.Yourvideohost.settings"
addon_name="iStream - Yourvideohost - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
