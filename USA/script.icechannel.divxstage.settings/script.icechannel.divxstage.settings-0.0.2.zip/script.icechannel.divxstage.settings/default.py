addon_id="script.icechannel.divxstage.settings"
addon_name="iStream - divxstage - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
