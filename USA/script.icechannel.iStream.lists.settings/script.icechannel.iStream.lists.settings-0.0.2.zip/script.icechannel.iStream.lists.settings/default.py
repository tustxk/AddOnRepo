addon_id="script.icechannel.iStream.lists.settings"
addon_name="iStream - iWatch - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
