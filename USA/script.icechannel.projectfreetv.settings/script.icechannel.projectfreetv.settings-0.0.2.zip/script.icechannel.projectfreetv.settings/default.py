addon_id="script.icechannel.projectfreetv.settings"
addon_name="iStream - projectfreetv - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
