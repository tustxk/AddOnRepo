xbmc-adult
==========

main repo for Frodo, Gotham, Helix and Isengard

See https://github.com/xbmc-adult/xbmc-adult/wiki/Devel before sending pull
requests
